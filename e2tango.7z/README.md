# e2tango Modbus GUI v1.0

Aplikacja GUI do odczytu i porównania danych z urządzeń Modbus e2tango i PQI-DA.

## Pliki w pakiecie

### Aplikacje:
- `dual_modbus_gui.py` - wersja deweloperska z debugowaniem
- `dual_modbus_gui_prod.py` - wersja produkcyjna bez debugowania
- `requirements.txt` - wymagane biblioteki Python

### Instalacja i uruchomienie:
- `install.bat` - automatyczny instalator (pobiera Python 3.11, instaluje zależności)
- `run_e2tango_gui.bat` - uruchomienie z widocznym terminalem
- `run_e2tango_gui_silent.bat` - uruchomienie z ukrytym terminalem
- `run_e2tango_gui_invisible.vbs` - uruchomienie całkowicie bezgłośne

## Instrukcja instalacji

### Opcja 1: Automatyczna instalacja
1. **Uruchom jako Administrator**: `install.bat`
2. Instalator automatycznie:
   - Pobierze i zainstaluje Python 3.11
   - Zainstaluje wymagane biblioteki
   - Utworzy skrypty uruchamiające
   - Utworzy skrót na pulpicie

### Opcja 2: Manualna instalacja
1. Zainstaluj Python 3.11 z https://python.org
2. Otwórz terminal w folderze aplikacji
3. Wykonaj: `py -3.11 -m pip install -r requirements.txt`

## Uruchamianie aplikacji

### Opcje uruchomienia:
1. **Z terminalem**: `run_e2tango_gui.bat`
2. **Bez terminala**: `run_e2tango_gui_silent.bat`
3. **Całkowicie ukryte**: `run_e2tango_gui_invisible.vbs`
4. **Bezpośrednio**: `py -3.11 dual_modbus_gui_prod.py`

## Funkcjonalności

### Połączenia Modbus:
- **e2tango**: domyślnie 192.168.41.99:502
- **PQI-DA**: domyślnie 192.168.41.95:502

### Odczytywane parametry:
- **Prądy**: I1, I2, I3 [A]
- **Napięcia**: U12, U23, U31 [V]
- **Częstotliwość**: f [Hz]
- **Moce**: P [W], Q [var], S [VA]
- **Współczynniki**: cos(φ), tg(φ)
- **Liczniki energii**: Ec+, Ec-, Eb+, Eb- [Wh, varh]
- **Moc średnia**: obliczana z różnic liczników energii

### Dodatkowe opcje:
- Skalowanie do kW/kWh
- Ukrywanie kolumn
- Regulacja częstotliwości odświeżania
- Automatyczne obliczanie mocy średniej

## Mapowanie rejestrów

| Parametr | e2tango | PQI | Jednostka |
|----------|---------|-----|-----------|
| I1 | 0x000 | 41016 | A |
| I2 | 0x002 | 41018 | A |
| I3 | 0x004 | 41020 | A |
| U12 | 0x006 | 41010 | V |
| U23 | 0x008 | 41012 | V |
| U31 | 0x00A | 41014 | V |
| f | 0x00C | 41000 | Hz |
| P | 0x00E | 1964 | W |
| Q | 0x010 | 1996 | var |
| S | 0x012 | 1968 | VA |
| cos(φ) | 0x014 | 2048 | - |
| tg(φ) | 0x016 | 2040 | - |
| Ec+ | 0x018 | 2184 | Wh |
| Ec- | 0x01A | 2168 | Wh |
| Eb+ | 0x01C | 2208 | varh |
| Eb- | 0x01E | 2200 | varh |

## Wymagania systemowe

- **System**: Windows 7/10/11
- **Python**: 3.11 lub nowszy
- **Biblioteki**: pymodbus >= 3.0.0
- **Sieć**: połączenie TCP/IP z urządzeniami Modbus

## Rozwiązywanie problemów

### "Python not found"
- Uruchom `install.bat` jako Administrator
- Lub zainstaluj Python 3.11 ręcznie i dodaj do PATH

### "pymodbus not found"
- Wykonaj: `py -3.11 -m pip install -r requirements.txt`
- Lub uruchom `install.bat`

### Brak połączenia z urządzeniami
- Sprawdź adresy IP urządzeń
- Sprawdź połączenie sieciowe
- Sprawdź czy porty 502 nie są blokowane

### Terminal się pokazuje
- Użyj `run_e2tango_gui_invisible.vbs`
- Lub zmień właściwości skrótu na "Minimized"

## Kontakt

Wersja: 1.0
Data: 2025-01-24